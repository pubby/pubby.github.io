Installing isocraft:

Paste isocraft.jar, start isocraft, tilesets, etc into a folder.
COPY the "com" folder from the MINECRAFT SERVER SOFTARE into the .jar file! THIS IS VERY IMPORTANT! ISOCRAFT WILL NOT RUN IF THE FOLDER
IS NOT PASTED INTO IT!
I can't inlcude the com folder in the download cause notch wrote it.

Using isocraft:
Have tileset and map in same folder.
Start isocraft.
Enter server name and .dat
enter tileset name with extension (.png)
enter savename with extension (image.png for instances)




Installing timelapse:
put files in server folder
copy "com" folder from minecraft server software into .jar file
start it up!

WILL SPAM TONS OF IMAGES INTO YOUR SERVER FOLDER!!!!
NEEDS WINDOWS TO WORK!